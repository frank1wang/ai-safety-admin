# AI安全王管理后台 (AI Safety King Admin Center)

工程安全AI识别应用的管理中心系统，为Android APP提供云端配置下发、AI模型管控、隐患知识库管理、图片样本库管理、RAG知识库、识别任务云端存储与复核等完整能力。

## 项目结构

```
ai-safety-admin/
├── backend/              # Node.js + Express 后端服务
│   ├── config/          # 配置文件（数据库、MinIO、AI模型）
│   ├── middleware/      # 中间件（认证、权限）
│   ├── models/          # 数据模型（如需ORM）
│   ├── routes/          # API路由（11个模块路由）
│   ├── services/        # 业务逻辑服务
│   ├── utils/           # 工具函数
│   ├── app.js           # 应用入口
│   ├── seed.js          # 数据库初始化
│   ├── .env.example     # 环境变量模板
│   └── package.json     # 后端依赖
│
├── frontend/            # React + Ant Design 前端管理后台
│   ├── public/          # 静态资源
│   └── src/
│       ├── api/         # Axios API封装
│       ├── components/  # 公共组件
│       ├── pages/       # 页面组件（12个页面）
│       └── utils/       # 工具函数
│
├── docker-compose.yml   # Docker编排配置
└── README.md            # 项目说明
```

## 核心功能模块

### P0 必做模块

1. **安全隐患与规范知识库管理**
   - 安全标准库：JGJ/GB等国家建筑规范维护（编号、名称、条文内容）
   - 隐患字典库：隐患类型、风险等级、关联规范、整改措施、整改期限
   - 版本管理：支持草稿/发布状态，修改后可回滚
   - 批量导入：Excel导入标准条文和隐患条目
   - APP接口：APP拉取最新隐患字典与安全标准，无需更新APK

2. **图片样本库管理**
   - 样本上传与标注：隐患类型、风险等级、期望输出
   - 正样本/负样本分类管理
   - 精选样本标记，作为few-shot示例供大模型调用
   - 历史识别图片云端归档
   - 复核后的样本自动沉淀到样本库

3. **大模型调用管控中心**
   - 多模型配置：支持配置多个大模型API Key（DeepSeek/Qwen/Gemini），切换默认模型
   - Prompt模板管理：后台编辑系统提示词，支持在线调试预览
   - 推理参数配置：temperature、max_tokens、RAG开关、few-shot开关
   - 调用统计：每日请求量、成功率、token消耗、设备调用日志
   - 限流管控：单设备每日最大识别次数限制
   - 紧急关停：一键关闭AI识别服务

### P1 强烈建议模块

4. **云端识别任务与隐患复核**
   - 识别任务列表：查看每次图片识别的完整记录（原图、AI输出、设备信息、时间、模型版本）
   - 人工复核：管理员标记AI识别正确/误判/漏判
   - 隐患筛选查询：按隐患类型、风险等级、时间、设备筛选
   - 数据看板：风险分布统计、高频隐患排行、每日识别趋势

5. **RAG文档知识库**
   - 上传PDF/Word安全规范文档
   - 文档切片入库，构建向量知识库
   - AI识别时检索知识库，减少大模型幻觉
   - 后台测试页面：上传测试图片直接测试识别效果

6. **数据导出与报表**
   - 隐患识别记录导出Excel/CSV
   - 安全标准库批量导出备份
   - 样本库导出备份

### P2 可选模块

7. **高级能力**
   - 设备黑白名单
   - 知识库灰度发布
   - 误判反馈接口
   - 高危隐患告警通知

## 技术栈

### 后端
- **Node.js** + **Express** - REST API框架
- **PostgreSQL** + **pgvector** - 关系型数据库 + 向量扩展（RAG检索）
- **MinIO** - 对象存储（APK、图片、PDF文档）
- **bcryptjs** + **jsonwebtoken** - 认证与授权
- **multer** - 文件上传
- **xlsx** - Excel导入导出
- **pdf-parse** + **mammoth** - 文档解析

### 前端
- **React 18** - UI框架
- **Ant Design v5** - 组件库
- **Ant Design Charts** - 图表库
- **React Router v6** - 路由
- **Axios** - HTTP请求

## 快速启动

### 方式一：Docker Compose（推荐）

```bash
# 克隆项目后
cd ai-safety-admin

# 复制环境变量模板
cp backend/.env.example backend/.env

# 编辑 .env 文件，配置AI模型API Key
# 然后启动全部服务
docker-compose up -d

# 服务将运行在：
# - 前端管理后台: http://localhost
# - 后端API: http://localhost:3000
# - MinIO控制台: http://localhost:9001 (minioadmin/minioadmin)
# - PostgreSQL: localhost:5432
```

### 方式二：本地开发

**后端启动：**
```bash
cd backend
npm install
cp .env.example .env
# 编辑 .env 配置数据库和AI Key
npm run seed   # 初始化数据库
npm run dev    # 开发模式
```

**前端启动：**
```bash
cd frontend
npm install
npm start      # 开发服务器 http://localhost:3000
```

## 默认管理员账号

- 用户名：`admin`
- 密码：`admin123`
- 首次登录后请立即修改密码

## API文档

### APP接口（无需登录）

| 接口 | 方法 | 说明 |
|------|------|------|
| `/api/app/config` | GET | 获取APP全部配置（隐患字典+安全标准+模型配置+Prompt+推理参数） |
| `/api/app/recognize` | POST | 图片识别（核心链路：Prompt + few-shot + RAG → 大模型） |
| `/api/app/sync-tasks` | POST | 同步本地识别历史到云端 |
| `/api/app/version-check` | GET | 检查APK版本更新 |
| `/api/app/feedback` | POST | 提交误判反馈 |

### 管理后台接口（需管理员登录）

| 接口 | 方法 | 说明 |
|------|------|------|
| `/api/auth/login` | POST | 管理员登录 |
| `/api/standards` | CRUD | 安全标准库管理 |
| `/api/hazards` | CRUD | 隐患字典管理 |
| `/api/samples` | CRUD | 图片样本库 |
| `/api/models` | CRUD | AI模型配置 |
| `/api/prompts` | CRUD | Prompt模板 |
| `/api/inference` | GET/PUT | 推理设置与限流管控 |
| `/api/tasks` | GET/PUT | 识别任务与复核 |
| `/api/rag` | CRUD | RAG知识库 |
| `/api/export` | GET | 数据导出 |
| `/api/dashboard` | GET | 数据看板统计 |

## 系统架构

```
┌─────────────────────────────────────────────────────────┐
│                    Android APP                          │
│  拍照 → 上传图片 → 拉取配置 → 展示识别结果            │
└──────────────┬──────────────────────┬───────────────────┘
               │                      │
    /api/app/config       /api/app/recognize
               │                      │
┌──────────────▼──────────────────────▼───────────────────┐
│              AI安全王管理后台 (Node.js + Express)         │
│                                                          │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐   │
│  │知识库管理│ │样本库管理│ │模型管控  │ │任务管理  │   │
│  └────┬─────┘ └────┬─────┘ └────┬─────┘ └────┬─────┘   │
│       │            │            │            │          │
│  ┌────▼─────┐ ┌────▼─────┐ ┌────▼─────┐ ┌────▼─────┐   │
│  │PostgreSQL│ │MinIO(OSS)│ │AI Model  │ │RAG Vector│   │
│  │ +pgvector│ │  (图片)  │ │ (API调用)│ │  (检索)  │   │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘   │
│                                                          │
└─────────────────────────────────────────────────────────┘
                           │
                    Web管理后台 (React + AntD)
```

## 部署注意事项

1. **AI模型API Key**：必须在 `.env` 中配置至少一个有效的多模态大模型API Key（推荐Qwen-VL，国内直连稳定）
2. **MinIO存储**：APK文件、识别图片、RAG文档均存储在MinIO中，请确保磁盘空间充足
3. **数据库**：pgvector扩展用于RAG向量检索，请确保PostgreSQL版本≥14
4. **HTTPS**：生产环境必须配置HTTPS，确保图片和API传输安全
5. **备份**：定期备份PostgreSQL数据库和MinIO存储桶数据

## 开发路线图

### 近期（1-2周）
- [x] 项目基础架构搭建
- [x] 数据库设计与初始化
- [x] 后端API开发（P0模块）
- [x] 前端管理后台页面开发
- [ ] 接口联调测试
- [ ] APP端接口对接

### 中期（1-2月）
- [ ] RAG向量检索优化
- [ ] 大模型few-shot效果验证
- [ ] 数据看板图表完善
- [ ] 批量导入/导出优化
- [ ] 设备黑白名单

### 远期（3-6月）
- [ ] 私有化部署方案
- [ ] 多租户支持
- [ ] 移动端管理后台（H5）
- [ ] AI模型微调pipeline
- [ ] 企业级SSO集成

## 联系与支持

如有问题或建议，请联系开发团队。

---

**AI安全王科技有限公司**
