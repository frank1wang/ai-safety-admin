# AI安全王管理后台 - 云端部署指南

本文档提供多种云端部署方案，从最简单的到企业级方案，请根据您的预算和技术能力选择。

---

## 快速对比

| 方案 | 难度 | 月费用 | 适用场景 | 推荐度 |
|------|------|--------|----------|--------|
| **Railway / Render** | ⭐ | ¥0-200 | 快速验证、小规模试用 | ⭐⭐⭐⭐ |
| **腾讯云/阿里云轻量** | ⭐⭐ | ¥100-300 | 正式运营、国内用户 | ⭐⭐⭐⭐⭐ |
| **VPS自建 (Docker)** | ⭐⭐⭐ | ¥50-150 | 技术能力强、成本控制 | ⭐⭐⭐ |
| **Serverless (函数计算)** | ⭐⭐ | ¥0-500 | 流量波动大、按量付费 | ⭐⭐⭐ |
| **Kubernetes集群** | ⭐⭐⭐⭐⭐ | ¥1000+ | 大规模、高可用企业级 | ⭐⭐ |

---

## 方案一：Railway / Render（最快，5分钟上线）

适合：快速验证、demo演示、海外部署

### 1.1 Railway部署

**优点**：自动CI/CD、自带PostgreSQL、免费额度充足

步骤：

1. **准备代码**
   ```bash
   # 在GitHub创建仓库，上传项目代码
   git init
   git add .
   git commit -m "init"
   git remote add origin https://github.com/YOUR_NAME/ai-safety-admin.git
   git push -u origin main
   ```

2. **部署后端**
   - 登录 [railway.app](https://railway.app)
   - New Project → Deploy from GitHub repo
   - 选择你的仓库，Railway自动识别Node.js项目
   - 添加PostgreSQL数据库：New → Database → Add PostgreSQL
   - 设置环境变量（在Variables面板）：
     ```
     DB_HOST=${{Postgres.POSTGRES_HOST}}
     DB_PORT=${{Postgres.POSTGRES_PORT}}
     DB_NAME=${{Postgres.POSTGRES_DATABASE}}
     DB_USER=${{Postgres.POSTGRES_USER}}
     DB_PASSWORD=${{Postgres.POSTGRES_PASSWORD}}
     JWT_SECRET=your-random-secret-key
     NODE_ENV=production
     PORT=3000
     ```
   - Railway自动生成域名，如 `https://ai-safety-admin.up.railway.app`

3. **部署前端**
   - 修改 `frontend/.env`：
     ```
     REACT_APP_API_URL=https://ai-safety-admin.up.railway.app/api
     ```
   - 前端可部署到：
     - **Vercel** (vercel.com) - 拖拽上传或Git连接
     - **Netlify** (netlify.com) - 同上
   - 构建命令：`npm run build`
   - 输出目录：`build/`

4. **配置CORS**
   - 在Railway后端环境变量添加：
     ```
     FRONTEND_URL=https://your-frontend.vercel.app
     ```

### 1.2 Render部署

类似Railway，步骤：
1. 登录 [render.com](https://render.com)
2. New Web Service → 连接GitHub仓库
3. 选择Node.js环境
4. 添加PostgreSQL数据库
5. 配置环境变量
6. 前端部署到Static Site

---

## 方案二：腾讯云轻量应用服务器（推荐国内正式运营）

适合：国内用户访问、正式业务运营、性价比最高

### 2.1 购买服务器

1. 登录 [腾讯云](https://cloud.tencent.com)
2. 产品 → 轻量应用服务器
3. 推荐配置（月流量<1000次识别）：
   - **2核4G** 内存，带宽3Mbps，50GB SSD
   - 系统镜像：**Ubuntu 22.04**
   - 月费：约 **¥68-98**
4. 购买后重置密码，记下公网IP

### 2.2 服务器初始化

SSH登录服务器：
```bash
ssh root@YOUR_SERVER_IP

# 更新系统
apt update && apt upgrade -y

# 安装Docker
apt install -y docker.io docker-compose
systemctl enable docker
systemctl start docker

# 安装Node.js
apt install -y nodejs npm
npm install -g n
n 18

# 安装Git
apt install -y git

# 创建项目目录
mkdir -p /opt/ai-safety-admin
cd /opt/ai-safety-admin
```

### 2.3 上传项目代码

**方式A：Git克隆（推荐）**
```bash
cd /opt/ai-safety-admin
git clone https://github.com/YOUR_NAME/ai-safety-admin.git .
```

**方式B：SCP上传**
在本地终端执行：
```bash
scp -r ai-safety-admin/* root@YOUR_SERVER_IP:/opt/ai-safety-admin/
```

### 2.4 配置环境变量

```bash
cd /opt/ai-safety-admin/backend
cp .env.example .env
nano .env
```

编辑 `.env`：
```bash
# 数据库（使用服务器本地PostgreSQL或Docker）
DB_HOST=localhost
DB_PORT=5432
DB_NAME=ai_safety_admin
DB_USER=postgres
DB_PASSWORD=YourStrongPassword123!

# JWT（必须修改！）
JWT_SECRET=your-random-secret-key-change-this

# MinIO（使用服务器本地MinIO）
MINIO_ENDPOINT=localhost
MINIO_PORT=9000
MINIO_USE_SSL=false
MINIO_ACCESS_KEY=minioadmin
MINIO_SECRET_KEY=minioadmin
MINIO_BUCKET=ai-safety

# AI模型API Key（必须配置至少一个）
QWEN_API_KEY=sk-your-qwen-key
DEEPSEEK_API_KEY=sk-your-deepseek-key

# 前端地址（用于CORS）
FRONTEND_URL=http://YOUR_SERVER_IP

# 服务器
PORT=3000
NODE_ENV=production
```

### 2.5 Docker Compose部署（最简单）

```bash
cd /opt/ai-safety-admin

# 修改docker-compose.yml中的外部端口（避免冲突）
nano docker-compose.yml
```

修改端口映射（如果3000/80被占用）：
```yaml
services:
  backend:
    ports:
      - "3000:3000"  # 可改为 "8000:3000"
  
  frontend:
    ports:
      - "80:80"      # 可改为 "8080:80"
```

启动服务：
```bash
docker-compose up -d

# 查看日志
docker-compose logs -f backend

# 初始化数据库
docker-compose exec backend node seed.js
```

### 2.6 配置Nginx反向代理（推荐）

安装Nginx：
```bash
apt install -y nginx
```

创建配置文件：
```bash
cat > /etc/nginx/sites-available/ai-safety << 'EOF'
server {
    listen 80;
    server_name YOUR_SERVER_IP;  # 或你的域名
    
    # 前端静态文件
    location / {
        proxy_pass http://localhost:3001;  # 前端端口
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
    
    # 后端API
    location /api/ {
        proxy_pass http://localhost:3000/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        
        # 文件上传大小限制
        client_max_body_size 50M;
    }
    
    # MinIO文件访问
    location /files/ {
        proxy_pass http://localhost:9000/;
    }
}
EOF

ln -s /etc/nginx/sites-available/ai-safety /etc/nginx/sites-enabled/
rm /etc/nginx/sites-enabled/default
nginx -t
systemctl restart nginx
```

### 2.7 配置HTTPS（使用Let's Encrypt免费证书）

```bash
apt install -y certbot python3-certbot-nginx

# 申请证书（需要域名）
certbot --nginx -d your-domain.com

# 自动续期已配置，无需手动操作
```

如果没有域名，可以使用腾讯云提供的免费二级域名，或购买一个域名（约¥50/年）。

### 2.8 前端构建与部署

```bash
cd /opt/ai-safety-admin/frontend

# 修改API地址为生产环境
sed -i 's|REACT_APP_API_URL=.*|REACT_APP_API_URL=http://YOUR_SERVER_IP/api|' .env

# 安装依赖并构建
npm install
npm run build

# 将构建产物复制到Nginx目录
cp -r build/* /var/www/html/
```

### 2.9 设置开机自启

```bash
cat > /etc/systemd/system/ai-safety-admin.service << 'EOF'
[Unit]
Description=AI Safety Admin Backend
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/ai-safety-admin/backend
ExecStart=/usr/local/bin/node app.js
Restart=on-failure
Environment=NODE_ENV=production
Environment=PORT=3000

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable ai-safety-admin
systemctl start ai-safety-admin
```

### 2.10 防火墙配置

```bash
# 开放必要端口
ufw allow 22/tcp    # SSH
ufw allow 80/tcp    # HTTP
ufw allow 443/tcp   # HTTPS
ufw allow 3000/tcp  # 后端（如需直接访问）
ufw enable
```

---

## 方案三：阿里云函数计算FC（Serverless，按量付费）

适合：流量不稳定、不想维护服务器、快速扩展

### 3.1 部署后端函数

1. 登录 [阿里云函数计算](https://fc.console.aliyun.com)
2. 创建服务：`ai-safety-admin`
3. 创建函数：
   - 函数名：`backend`
   - 运行时：`Node.js 18`
   - 触发器：HTTP触发器
   - 代码上传：ZIP包上传
4. 配置环境变量（同上面的.env）
5. 绑定PostgreSQL（使用阿里云RDS PostgreSQL或TableStore）

### 3.2 部署前端

1. 使用**阿里云OSS静态网站托管**
2. 或使用**Vercel/Netlify**（免费）

### 3.3 费用估算

- 函数计算：前100万次调用免费，超出约¥0.013/万次
- RDS PostgreSQL：约¥50/月起
- OSS存储：约¥0.12/GB/月
- **预估月费：¥50-200**（取决于使用量）

---

## 方案四：Kubernetes集群（企业级）

适合：大规模部署、多环境管理、自动扩缩容

### 4.1 使用阿里云ACK或腾讯云TKE

1. 创建Kubernetes集群（3节点起）
2. 使用Helm Chart部署：
   ```bash
   helm install ai-safety-admin ./helm-chart \
     --set ingress.host=admin.your-domain.com \
     --set backend.env.JWT_SECRET=xxx
   ```

3. 配置Ingress + SSL自动续期

---

## 各云服务商对比

### 国内服务商

| 服务商 | 轻量服务器 | 数据库 | 对象存储 | 域名 | 备案 |
|--------|-----------|--------|----------|------|------|
| **腾讯云** | 轻量应用服务器 ¥68/月起 | Cloud PostgreSQL ¥50/月起 | COS ¥0.01/GB | 免费二级域名 | 需备案 |
| **阿里云** | ECS ¥99/年起 | RDS PostgreSQL ¥50/月起 | OSS ¥0.12/GB | 需购买 | 需备案 |
| **华为云** | 云耀云服务器 ¥99/年起 | RDS PostgreSQL ¥50/月起 | OBS | 需购买 | 需备案 |

### 海外服务商

| 服务商 | 费用 | 优点 | 缺点 |
|--------|------|------|------|
| **Railway** | $5/月起 | 自动部署、零配置 | 国内访问慢 |
| **Render** | $7/月起 | 简单稳定 | 国内访问慢 |
| **Vercel** | 免费 | 前端极速部署 | 仅前端 |
| **DigitalOcean** | $6/月起 | 稳定可靠 | 需手动配置 |
| **AWS Lightsail** | $5/月起 | 生态完善 | 学习曲线陡峭 |

---

## 数据库选择指南

### 选项A：云数据库（推荐）

**阿里云RDS PostgreSQL**
- 创建实例 → 选择PostgreSQL 14+ → 开启pgvector扩展
- 费用：约¥50-200/月
- 优点：自动备份、监控、高可用

**腾讯云Cloud PostgreSQL**
- 类似阿里云，费用相近

### 选项B：服务器自建PostgreSQL

```bash
# Docker运行PostgreSQL+pgvector
docker run -d \
  --name ai-safety-db \
  -e POSTGRES_DB=ai_safety_admin \
  -e POSTGRES_USER=postgres \
  -e POSTGRES_PASSWORD=yourpassword \
  -v /opt/postgres-data:/var/lib/postgresql/data \
  -p 5432:5432 \
  ankane/pgvector:latest
```

### 选项C：Neon/Supabase（免费额度）

**Neon** (neon.tech)
- 免费额度：500MB存储，100k请求/月
- 支持pgvector
-  Serverless PostgreSQL

**Supabase** (supabase.com)
- 免费额度：500MB存储
- 自带pgvector
- 支持Row Level Security

---

## MinIO对象存储部署

### 选项A：服务器自建（推荐小规模）

已在docker-compose.yml中配置，无需额外操作。

### 选项B：阿里云OSS

```bash
# 修改backend/.env
MINIO_ENDPOINT=oss-cn-beijing.aliyuncs.com
MINIO_PORT=443
MINIO_USE_SSL=true
MINIO_ACCESS_KEY=your-access-key
MINIO_SECRET_KEY=your-secret-key
MINIO_BUCKET=your-bucket-name
```

### 选项C：腾讯云COS

类似OSS，修改对应配置。

---

## 域名与备案

### 国内部署（必须备案）

1. 购买域名（腾讯云/阿里云，约¥50/年）
2. 实名认证
3. ICP备案（约7-20天）
4. 配置DNS解析到服务器IP
5. 申请SSL证书

### 海外部署（无需备案）

1. 购买域名（Namecheap/Cloudflare，约$10/年）
2. 配置DNS解析
3. 使用Cloudflare CDN（免费SSL+加速）

---

## 监控与运维

### 基础监控

```bash
# 安装docker stats查看容器资源
docker stats

# 查看后端日志
docker-compose logs -f backend --tail 100

# 查看数据库日志
docker-compose logs -f postgres
```

### 高级监控（可选）

- **Uptime Kuma**：服务可用性监控（开源免费）
- **Grafana + Prometheus**：性能指标监控
- **Sentry**：错误追踪（免费额度）

---

## 备份策略

### 数据库备份

```bash
# 手动备份
pg_dump -h localhost -U postgres ai_safety_admin > backup_$(date +%Y%m%d).sql

# 自动备份（添加到crontab）
0 2 * * * pg_dump -h localhost -U postgres ai_safety_admin > /opt/backups/db_$(date +\%Y\%m\%d).sql
```

### MinIO数据备份

```bash
# 备份MinIO数据目录
tar -czf minio_backup_$(date +%Y%m%d).tar.gz /opt/minio-data
```

---

## 故障排查

### 常见问题

**1. 前端无法访问后端API**
- 检查CORS配置：`FRONTEND_URL`是否正确
- 检查防火墙：端口是否开放
- 检查Nginx配置：反向代理是否正确

**2. 数据库连接失败**
- 检查PostgreSQL是否运行：`docker ps | grep postgres`
- 检查环境变量：DB_HOST/PORT/USER/PASSWORD是否正确
- 检查防火墙：5432端口是否开放（建议不开放，只内部访问）

**3. 图片上传失败**
- 检查MinIO是否运行
- 检查磁盘空间：`df -h`
- 检查上传大小限制：Nginx的`client_max_body_size`

**4. AI识别无响应**
- 检查API Key是否配置
- 检查网络：能否访问AI服务商（如阿里云百炼）
- 查看后端日志：模型调用报错信息

---

## 性能优化

### 1. 启用CDN（图片加速）

使用腾讯云COS/阿里云OSS + CDN：
- 图片访问速度提升5-10倍
- 费用：约¥0.1/GB流量

### 2. 数据库优化

```sql
-- 为常用查询添加索引
CREATE INDEX idx_tasks_device_id ON recognition_tasks(device_id);
CREATE INDEX idx_tasks_created_at ON recognition_tasks(created_at);
CREATE INDEX idx_hazards_status ON hazard_dictionary(status);
```

### 3. 缓存

- 使用Redis缓存热点数据
- 或使用Node-cache做内存缓存

### 4. 压缩

```bash
# Nginx启用Gzip压缩
sed -i 's/# gzip on/gzip on/' /etc/nginx/nginx.conf
systemctl restart nginx
```

---

## 安全加固

### 必做清单

- [ ] 修改默认管理员密码
- [ ] 修改JWT_SECRET为随机长字符串
- [ ] 配置防火墙，只开放必要端口
- [ ] 启用HTTPS（SSL证书）
- [ ] 定期更新系统：`apt update && apt upgrade`
- [ ] 定期备份数据库
- [ ] 配置fail2ban防止暴力破解
- [ ] 使用强密码策略

### 安装fail2ban

```bash
apt install -y fail2ban
cat > /etc/fail2ban/jail.local << 'EOF'
[DEFAULT]
bantime = 3600
findtime = 600
maxretry = 5

[sshd]
enabled = true
EOF
systemctl restart fail2ban
```

---

## 更新部署

### 代码更新流程

```bash
cd /opt/ai-safety-admin

# 拉取最新代码
git pull origin main

# 重新构建并重启
docker-compose down
docker-compose up -d --build

# 执行数据库迁移（如有更新）
docker-compose exec backend node seed.js
```

### 零停机更新（使用Docker滚动更新）

```bash
# 构建新版本镜像
docker-compose build backend

# 滚动更新
docker-compose up -d --no-deps --build backend
```

---

## 推荐配置总结

### 最小可用配置（月费用约¥100）

| 组件 | 选择 | 费用 |
|------|------|------|
| 服务器 | 腾讯云轻量2核4G | ¥68/月 |
| 数据库 | 服务器自建PostgreSQL | ¥0 |
| 对象存储 | 服务器自建MinIO | ¥0 |
| 域名 | 免费二级域名 | ¥0 |
| **合计** | | **¥68-100/月** |

### 正式运营配置（月费用约¥300）

| 组件 | 选择 | 费用 |
|------|------|------|
| 服务器 | 腾讯云ECS 4核8G | ¥200/月 |
| 数据库 | 阿里云RDS PostgreSQL | ¥100/月 |
| 对象存储 | 阿里云OSS + CDN | ¥50/月 |
| 域名+SSL | 域名¥50/年 + SSL免费 | ¥5/月 |
| **合计** | | **¥355/月** |

---

## 需要帮助？

如有部署问题，请提供：
1. 选择的部署方案
2. 服务器/平台信息
3. 错误日志截图
4. 当前执行到哪一步

祝你部署顺利！🚀
